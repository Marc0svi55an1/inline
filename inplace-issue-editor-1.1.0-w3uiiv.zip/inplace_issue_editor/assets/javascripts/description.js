$(document).ready(function () {
  var url = window.location.origin;   //get url
  var q = window.location.href;
  var r = new URL(q).pathname;   //issue id find 
  var old_data ;                 //get old data of issue description  in textiles farmate
  var plainText_old_data ;       //old data convert to text
  var api_key = localStorage.getItem("issue_table_api_key");
  
  //var turndownService = new TurndownService();    //markdown convert function
 // var set_textformate =  '<%= Setting.text_formatting %>' ; 


//  console.log(issue_table_api,"issue table in description file")

//  ----------------getting issue description data from database ------------------

    $.ajax({
        url: `${url}${r}.json?key=${api_key}`,
        type: "GET",
        crossDomain: true,
        dataType: "json",
       success: function (data) {
        console.log(data,"data");
         var issues_data = data.issue;
         old_data = issues_data.description      //get on variable 
         console.log(old_data,"old adata")
         if(old_data!=null)
         {
          plainText_old_data = textile.convert(old_data);   //convert it to text
         }
         else{
          plainText_old_data = ""
         }
         
       }
       
      });
// ----------------------------function that remove css of table ------------------

function removeTableInlineCSS(formData) {
  if (!formData.includes('<table')) 
  return formData;
  else {
  // Create a new HTML element to store the form data
  var tempElement = document.createElement('div');
  tempElement.innerHTML = formData;

  // Find all the table elements within the form data
  var tableElements = tempElement.querySelectorAll('table');

  // Loop through each table element and remove any inline CSS styles
  tableElements.forEach((table) => {
    table.removeAttribute('style');
  });

  // Return the updated form data with tables' inline CSS removed
  return tempElement.innerHTML;
}
}

  
  // -----------function that is convert only html table ------------
  
  function htmltableToTextile(html) {
    if (!html.includes('<table>')) return html;
  
    // convert HTML table to Textile
    let textile = html.replace(/<table>/g, "").replace(/<\/table>/g, "");
    textile = textile.replace(/<tbody>/g, "").replace(/<\/tbody>/g, "");
    textile = textile.replace(/<tr>/g, "|").replace(/<\/tr>/g, "<br>");
    textile = textile.replace(/<td>/g, "").replace(/<\/td>/g, "|");
    return textile;
  }

  // -----------------function that is convert only strikethrough data------------

    function strikethrough_convet(html) {
    if (!html.includes("<s>")) return html;
  
    // convert HTML striket words to Textile
    let textile = html.replace(/<s>/g, "-").replace(/<\/s>/g, "-");
    return textile;
  }

// -------------function that converted only image---------------
  
    function img_convet(htmlString) {
    const doc = new DOMParser().parseFromString(htmlString, "text/html");
    const images = doc.getElementsByTagName("img");
  
    if (images.length === 0) {
      return htmlString; // no images found, return original string
    }
  
    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      const src = img.getAttribute("src");
      const alt = img.getAttribute("alt") || "";
  
      const textileString = `!${alt}${src}!`;
  
      const parent = img.parentNode;
      const replacement = doc.createTextNode(textileString);
      parent.replaceChild(replacement, img);
    }
  
    return doc.body.innerHTML;
  }

  // ---------function that convert only anchor tag--------------
  
  // function anchor_convet(htmlString) {
  //   const doc = new DOMParser().parseFromString(htmlString, "text/html");
  //   const anchor = doc.getElementsByTagName("a");
  
  //   if (anchor.length === 0) {
  //     return htmlString; // no images found, return original string
  //   }
  
  //   for (let i = 0; i < anchor.length; i++) {
  //     const img = anchor[i];
  //     const href = img.getAttribute("href");
  //     const alt = img.getAttribute("alt") || "";
  
  //     const textileString = `[[${alt}${href}]]`;
  
  //     const parent = img.parentNode;
  //     const replacement = doc.createTextNode(textileString);
  //     parent.replaceChild(replacement, img);
  //   }
  
  //   return doc.body.innerHTML;
  // }

// ---------------------function that convert image base64 to textiles --------------

// function imagetotextile(base64Str) {
//   // check if the base64 string is an image
//   if (!/^data:image\/(png|jpeg);base64,/.test(base64Str)) {
//     //console.log(base64Str);
//     return base64Str;
//   }

//   // remove the data:image/png;base64, part of the string
//   var base64Img = base64Str.replace(/^data:image\/(png|jpeg);base64,/, "");

//   // convert the base64 string to a Uint8Array
//   var raw = atob(base64Img);
//   var rawLength = raw.length;
//   var array = new Uint8Array(new ArrayBuffer(rawLength));
//   for(var i = 0; i < rawLength; i++) {
//     array[i] = raw.charCodeAt(i);
//   }

//   // create a Blob object from the Uint8Array
//   var blob = new Blob([array], {type: "image/png"});

//   // create a FormData object and append the Blob to it
//   var formData = new FormData();
//   formData.append("file", blob, "image.png");

//   // send a POST request to the server to convert the image to textile format
//   var xhr = new XMLHttpRequest();
//   xhr.open("POST", "/convertImageToTextile");
//   xhr.onload = function() {
//     if (xhr.status === 200) {
//       // get the textile string from the response and do something with it
//       var textileStr = xhr.responseText;
//       console.log(textileStr);
//     }
//   };
//   xhr.send(formData);
// }



// ----------------blob convert-----------

// function convertImageToBlob(htmlContent) {
//   const parser = new DOMParser();
//   const doc = parser.parseFromString(htmlContent, 'text/html');
//   const images = doc.getElementsByTagName('img');
  
//   for (let i = 0; i < images.length; i++) {
//     const img = images[i];
//     const src = img.getAttribute('src');
    
//     if (src.startsWith('data:image')) {
//       // already a data URL, nothing to do
//       continue;
//     }
    
//     const xhr = new XMLHttpRequest();
//     xhr.open('GET', src, true);
//     xhr.responseType = 'blob';
    
//     xhr.onload = () => {
//       if (xhr.status === 200) {
//         const blobUrl = URL.createObjectURL(xhr.response);
//         img.setAttribute('src', blobUrl);
//       }
//     };
    
//     xhr.send();
//   }
  
//   return doc.documentElement.outerHTML;
// }



// tinymce.init({
//   selector: '#editor2',  
//   height: 200,
//   menubar: false,
//   plugins: [
//     'advlist' , 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
//     'anchor', 'searchreplace', 'visualblocks', 'fullscreen',   
//     'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount' 
//   ],
//   toolbar: 'undo redo | blocks | bold italic underline strikethrough preview  | ' +
//     'image  table link pre code  blockquote insertdatetime | ' +
//     'bullist numlist outdent indent | help ',


//     // table_default_attributes: {},
//     // table_default_styles: {},

//     // images_upload_url: 'postAcceptor.php',
//     // //images_upload_url: '/api/upload/image',
//     //  automatic_uploads: false

//     // remove_table_styles: true,
//     // //table_appearance_options: false,
//     // table_use_colgroups: false,
//     // table_advtab: false,
//     // table_style_by_css: false,
//     // table_tab_navigation: false,
//     // // table_default_attributes: false, 
//     // //table_default_styles: false,
//     // table_row_advtab: false,
//     // table_cell_advtab: false,
   
//   });



// ---------------------save and cancel button --------------------

  $('.controller-issues.action-show form#fakeDynamicForm .issue .description').append("<button class='cancel_desc'><i class='fa-solid fa-xmark '></i></button> ");
  $('.controller-issues.action-show form#fakeDynamicForm .issue .description').append("<button class='save_desc'><i class='fa-solid fa-check'></i></button> ");
 
  
// -----------------------double click on issue description then open tiny editor ---------------
  // take a variable to initialize with false
var editor2Appended = false;
$('.controller-issues.action-show form#fakeDynamicForm .issue .description .iconEdit').click(function () {


  $('.controller-issues.action-show form#fakeDynamicForm .issue .description .wiki').css('display','none');
  $('.controller-issues.action-show form#fakeDynamicForm .issue .description button.save_desc').css('display','inline-block');
  $('.controller-issues.action-show form#fakeDynamicForm .issue .description button.cancel_desc').css('display','inline-block');
  
  

  if(!editor2Appended)
  {
  $('.controller-issues.action-show form#fakeDynamicForm .issue .description ').append("<textarea id = editor2 > </textarea>");
    editor2Appended = true; 
  }
  
  
  tinymce.init({
    selector: '#editor2',  
    height: 200,
    menubar: false,
    plugins: [
      'advlist' , 'autolink', 'lists', 'link',
      'anchor','visualblocks',
       'table',
    ],
    toolbar: 'undo redo | blocks | bold italic underline strikethrough  | ' +
      'image  table link pre   blockquote  | ' +
      'bullist numlist outdent indent | ',
  
  
      table_default_attributes: {},
      table_default_styles: {},
      images_upload_url: 'postAcceptor.php',
      //images_upload_url: '/api/upload/image',
       automatic_uploads: false,
      remove_table_styles: true,
      //table_appearance_options: false,
      table_use_colgroups: false,
      table_advtab: false,
      table_style_by_css: false,
      table_tab_navigation: false,
      // table_default_attributes: false, 
      //table_default_styles: false,
      table_row_advtab: false,
      table_cell_advtab: false,


      
      
    });

    
   console.log(plainText_old_data,"plain text old data")
     // tinymce textarea put old descriptiion data
    document.getElementById("editor2").innerHTML = plainText_old_data ;
        
    
});



// ---------------------------FOCUS OUT FUNCTION-------------------
//  -----------------------when click outside save automatice and hide ------------

    //  document.addEventListener("click", function(event) {
    //     var editor5 = tinymce.activeEditor;
    //     var target = event.target;
    //     if (!editor5.getBody().contains(target)) {
    //        editor5.hide();
    //        $('#editor2').hide();
// ------------------------------------------------------------------------------------
    

// ---------------------save button functionality----------------
   
$(".controller-issues.action-show form#fakeDynamicForm .issue .description button.save_desc").click(function(){
    
          var myContent = tinymce.get("editor2").getContent();     //get data in html formate
          var data_2 =  strikethrough_convet(myContent);           // striket style add
          var data_56 = removeTableInlineCSS(data_2);
          var data_3 = htmltableToTextile(data_56);                 // table convert in textiles
          //data_44 = convertImageToBlob(data_3);                 //  image convert
          var data_4 = img_convet(data_3);                         // image data convert
          //var data_5 = anchor_convet(data_3);                     //anchor convert to wiki link
          //var data_4 = imagetotextile(data_3);
                                
          var data_6 = toTextile(data_4);                          //all data convert in textile
         //alert(data_6);
          // -------put API for description save database--------
          //console.log(data_3);

             console.log(data_6,"data2")
          var content = {
                  description: data_6,
                }
               
                $.ajax({
                     type: "PUT",
                     url: `${url}${r}.json?key=${api_key}`,
                     contentType: "application/json; charset=utf-8",
                     dataType: "json",
                     data: JSON.stringify({
                       issue: content
                     }),
                     success: function () {
                      // window.location.reload();
                     }
                 })
        
                  

    });



    // ------------------cancel button functionality----------------
      
    $(".controller-issues.action-show form#fakeDynamicForm .issue .description button.cancel_desc").click(function(){
   
      $('#content > div.issue > div.description > div.wiki').css('display','block');
      $('div.tox.tox-tinymce').css('display','none');
      $('button.save_desc').css('display','none');
      $('button.cancel_desc').css('display','none');
      // window.location.reload();
    });

});
// --------------------------end----------------------


/********* Issue Editor **********/ 

var url_https = url_https || false;
var edit_icon = edit_icon || "single";
var event_value = event_value || "click";
var type_icon = type_icon || "none";
var target_value = target_value || "value";
var excluded_field_id = excluded_field_id || [];
var check_update_conflict = check_update_conflict || false;


var LOCATION_HREF = typeof custom_location_href !== 'undefined' ? custom_location_href : window.location.href;

var svg_pencil = `<svg width="12" height="14" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.6045 5.2808L17.8579 7.02704L13.8584 3.02715L15.6613 1.22427C16.112 0.773551 16.9568 0.773551 17.4642 1.22427L19.7173 3.47742C20.1114 3.98472 20.1114 4.77339 19.6045 5.28069L19.6045 5.2808Z" fill="#1D273C"/>
<path d="M1.46498 15.4773C3.15509 16.3221 4.56343 17.7304 5.40823 19.3644L0 20.8855L1.46498 15.4773ZM6.25313 18.6319C5.35171 16.9418 3.94336 15.4773 2.25325 14.632L13.0693 3.81592L17.0692 7.81581L6.25313 18.6319Z" fill="#1D273C"/>
</svg>`;


if (url_https) {
	LOCATION_HREF = LOCATION_HREF.replace(/^http:\/\//i, 'https://');
}


const updateCSRFToken = function(token){
	document.querySelectorAll('input[name="authenticity_token"]').forEach((elt) => elt.value = token);
	document.querySelector('meta[name="csrf-token"]').setAttribute("content", token);
}

const setCSRFTokenInput = function(token){
	document.querySelectorAll('form[method="post"]').forEach((elt) => {
		if(!elt.querySelectorAll('input[name="authenticity_token"]').length){
			const input = document.createElement("input");
			input.setAttribute("type", "hidden");
			input.setAttribute("name", "authenticity_token");
			input.value = token;
			elt.insertBefore(input, null);
		}
	});
}


var getEditFormHTML = function(attribute){
	let formElement =  document.querySelector('#issue_' + attribute + "_id");
	formElement = formElement ? formElement : document.querySelector('#issue_' + attribute);
	formElement = formElement ? formElement : document.querySelector('#' + attribute);
   
	// Checkbox specific case
	let is_checkboxes = false;
	let is_file = false;
	let is_list = false;
	let CF_ID = false;
	if(!formElement && attribute.startsWith("custom_field_values_")){
		CF_ID = attribute.split("custom_field_values_")[1];
		/* Is it a checkbox block ? */
		formElement = document.querySelector('#issue_custom_field_values_' + CF_ID);
		if(formElement){
			formElement = formElement.closest('.check_box_group');
			is_checkboxes = CF_ID;
		} else {
			/* Is it a file block ? */
			formElement = document.querySelector('#issue_custom_field_values_' + CF_ID + '_blank');
			if(formElement){
				formElement = formElement.closest('p');
				formElement.removeChild(formElement.querySelector('label'));
				is_file = CF_ID;
			} else {
				/* Is it a checkbox/radio group ? */
				formElement = document.querySelector('#issue-form .cf_' + CF_ID + '.check_box_group');
				is_list = CF_ID;
			}
		}
	}

	if(formElement){
		const clone = formElement.cloneNode(true);
		
		if(clone.matches('select') && !clone.hasAttribute('multiple')) {
			clone.addEventListener('change', function(e){
				sendData([{"name" : clone.getAttribute('name'), "value" : clone.value}]);
			});
		}
		if(clone.matches('input')){
			
			clone.addEventListener("keydown", function(event) {
				if (event.key === "Enter") {
					sendData([{"name" : clone.getAttribute('name'), "value" : clone.value}]);
					clone.blur();
				}
			});
		}
		if(clone.matches('input[type="date"]')) {
			clone.addEventListener('change', function() {
				sendData([{"name" : clone.getAttribute('name'), "value" : clone.value}]);
			});

		}
		if(is_checkboxes || is_file || is_list) {
			clone.setAttribute('id', "issue_custom_field_values_" + CF_ID + "_dynamic");
		} else {
			clone.setAttribute('id', formElement.getAttribute('id') + "_dynamic");
		}
		const wrapper = document.createElement('div');
		wrapper.classList.add('issueEdit');
		wrapper.insertBefore(clone, null);
		
		return wrapper;
       
	}

	return null;
}


const cloneEditForm = function(){

	const wrapper = document.createElement('form');
	wrapper.setAttribute('id', 'fakeDynamicForm');
	document.querySelector('.issue.details').parentNode.insertBefore(wrapper, document.querySelector('.issue.details'));
	wrapper.appendChild(document.querySelector('.issue.details'));
    
	document.querySelectorAll('div.issue.details .attribute').forEach(function(elt){
		const classList = elt.classList.value.split(/\s+/);

		let attributes = classList.filter(function(elem) { return elem != "attribute"; });
		
		attributes = attributes.map((attr) => attr.replaceAll('-', '_'));

		let custom_field = false;
		attributes.forEach(function(part, index, arr) {
		  if(arr[index] === "progress") arr[index] = "done_ratio";
		  if(arr[index].startsWith('cf_')) {
		  	arr[index] = arr[index].replace('cf', 'custom_field_values');
		  	custom_field = arr[index];
		  }
		});

		attributes = attributes.join(" ");

		let selected_elt = custom_field ? custom_field : attributes;
		if(attributes && !excluded_field_id.includes(selected_elt)){
			let dynamicEditField = getEditFormHTML(selected_elt);
			if (dynamicEditField) {
				let btn_edit = document.createElement('span');
				btn_edit.classList.add('iconEdit');
				btn_edit.innerHTML = svg_pencil;
				if (elt.querySelector('.value')) {
				  let valueElement = elt.querySelector('.value');
				  valueElement.insertBefore(btn_edit, null);
				  valueElement.insertBefore(dynamicEditField, null);
				}
			}
			// if(dynamicEditField){
			// 	let btn_edit = document.createElement('span');
			// 	btn_edit.classList.add('iconEdit');
			// 	btn_edit.innerHTML = svg_pencil;
			// 	if (elt.querySelector('.value')){
			// 		elt.querySelector('.value').insertBefore(btn_edit, null);
			// 	    elt.querySelector('.value').insertBefore(dynamicEditField, null);
			// 	}
				
			// }
		}
  	});

  	
  	if(!excluded_field_id.includes("description") && document.querySelectorAll('div.issue.details .description').length){
		const btn_edit = document.createElement('span');
		btn_edit.classList.add('iconEdit');
		btn_edit.innerHTML = svg_pencil;
  		document.querySelector('div.issue.details .description > p strong').insertAdjacentElement("afterend", btn_edit);
  		const formDescription = getEditFormHTML("description");
  		// formDescription.querySelector("#issue_description_dynamic").removeAttribute('data-tribute');
  		// document.querySelector('div.issue.details .description').insertBefore(formDescription, null);

  		// if (
		// 		typeof(CKEDITOR) === "object" &&
		// 		typeof(CKEDITOR.instances['issue_description'] !== "undefined") &&
		// 		typeof(CKEDITOR.instances['issue_description'].getData) === typeof(Function)
		// ) {
		// 	const cfg = CKEDITOR.instances['issue_description'].config;
		// 	cfg.height = 100;
		// 	CKEDITOR.replace("issue_description_dynamic", cfg)
		// }else if (typeof(jsToolBar) === typeof(Function)) {
		// 	const DynamicDescriptionToolbar = new jsToolBar(document.querySelector('#issue_description_dynamic'));
		// 	DynamicDescriptionToolbar.setHelpLink('/help/en/wiki_syntax_common_mark.html');
		// 	DynamicDescriptionToolbar.setPreviewUrl('/issues/preview?issue_id=' + _ISSUE_ID + '&project_id=' + _PROJECT_ID); 
		// 	DynamicDescriptionToolbar.draw();
		// }
  	}

  	
  	if(!excluded_field_id.includes("issue_subject")){

		const btn_edit = document.createElement('span');
		btn_edit.classList.add('iconEdit');
		btn_edit.innerHTML = svg_pencil;
		document.querySelector('div.issue.details div.subject h3').insertBefore(btn_edit, null);
  		const formTitle = getEditFormHTML("issue_subject");
  		document.querySelector('div.issue.details div.subject').insertBefore(formTitle, null);
  	}
}

document.querySelector('body').addEventListener(event_value,
	function(e){
	   let is_attribute = e.target.matches('div.issue.details .attributes .attribute .' + target_value) || e.target.closest('div.issue.details .attributes .attribute .' + target_value);
	   let is_description = e.target.matches('div.issue.details div.description > p') || e.target.closest('div.issue.details div.description > p');
	   let is_subject = e.target.matches('div.issue.details div.subject') || e.target.closest('div.issue.details div.subject');
	   if(is_attribute || is_description || is_subject ){
		   if(e.target.closest('.issueEdit')) return; 
			document.querySelectorAll('.issueEdit').forEach(function(elt){ elt.classList.remove('open'); });
		   if(!e.target.closest('a') && !e.target.closest('button')){
			   let selector = e.target.closest('.value');
			   if(is_description) selector = e.target.closest('.description');
			   if(is_subject) selector = e.target.closest('.subject');
			   if(selector.querySelector('.issueEdit'))
			   {
				selector.querySelector('.issueEdit').classList.add('open');
			   }
		   }
	   }
});

document.querySelector('body').addEventListener(type_icon, function(e){
	let is_attribute = e.target.matches('div.issue.details .attributes .attribute .' + target_value) || e.target.closest('div.issue.details .attributes .attribute .' + target_value);
	let is_description = e.target.matches('div.issue.details div.description > p') || e.target.closest('div.issue.details div.description > p');
	let is_subject = e.target.matches('div.issue.details div.subject') || e.target.closest('div.issue.details div.subject');
	if(e.target.matches('.iconEdit') || e.target.closest('.iconEdit')){
		document.querySelectorAll('.issueEdit').forEach(function(elt){ elt.classList.remove('open'); });
		let selector = e.target.closest('.value');
		if(is_description) selector = e.target.closest('.description');
		if(is_subject) selector = e.target.closest('.subject');
		selector.querySelector('.issueEdit').classList.add('open');
	}
});


document.querySelector('body').addEventListener('click', function(e){
	if(e.target.matches('.refreshData') || e.target.closest('.refreshData')){
		e.preventDefault();
		sendData();
	}
});

/* Listen on esc key press to close opened dialog box */
document.onkeydown = function(evt) {
    evt = evt || window.event;
    let isEscape = false;
    if ("key" in evt) {
        isEscape = (evt.key === "Escape" || evt.key === "Esc");
    } else {
        isEscape = (evt.keyCode === 27);
    }
    if (isEscape) {
        document.querySelectorAll('.issueEdit').forEach(function(elt){ elt.classList.remove('open'); });
    }
};

const getVersion = function(callback){
	fetch(LOCATION_HREF, {
		method: 'GET',
		crossDomain: true,
	}).then(res => res.text()).then(data => {
		const parser = new DOMParser();
		const doc = parser.parseFromString(data, 'text/html');
		const distant_version = doc.querySelector('#issue_lock_version').value;
		if(callback) callback(distant_version);
		return distant_version;
	}).catch(err => {
		console.warn('Issue while trying to get version (avoiding conflict)');
		console.log(err);
	});
}

let loadedDate = new Date();
const checkVersion = function(callback){

	fetch(LOCATION_HREF + ".json", {
		method: 'GET',
		crossDomain: true,
	}).then(res => res.text()).then(data => {
		try {
			const parsedData = JSON.parse(data);
			const lastUpdate = new Date(parsedData.issue.updated_on);
			if(lastUpdate > loadedDate){
				loadedDate = lastUpdate;
				if(!document.querySelectorAll('#content .conflict').length){
					let msg = document.createElement('div');
					msg.classList.add('conflict');
					msg.innerHTML = `${_TXT_CONFLICT_TITLE}
					<div class="conflict-details">
					<div class="conflict-journal">
					<p><a href='#' onClick="window.location.href=window.location.href">${_TXT_CONFLICT_LINK}</a> <strong>${_TXT_CONFLICT_TXT}</strong></p>
					</div>
					</div>`
					document.querySelector('#content').insertBefore(msg, document.querySelector('#content').firstChild);
				}
				if(callback) getVersion(callback);
			} else {
				if(callback) callback(parseInt(document.querySelector('#issue_lock_version').value));
			}
		} catch (e) {
			throw new Error('Error occured: ', e);
		}
		
	}).catch(err => {
		console.warn('Issue while trying to get version (avoiding conflict)');
		console.log(err);
	});
}




/* Global function to perform AJAX call */
let sendData = function(serialized_data){
	let updateIssue = function(serialized_data){
		
		const token = document.querySelector("meta[name=csrf-token]").getAttribute('content');
		let params = serialized_data || [];
		params.push({name: '_method', value: "patch"});
		params.push({name: 'authenticity_token', value: token});

		let request = new XMLHttpRequest();
		request.open('POST', LOCATION_HREF, true);
		let formData = new FormData();
		params.forEach(data => formData.append(data.name, data.value));

		let callError = function(msg){
			
			document.querySelector('#ajax-indicator').style.display = 'none';

			/* error and no update, info logged into console */
			console.groupCollapsed('%c -------- Error while updating the issue attribute dynamically -------- ', 'background: #ff0000; color: white; font-weight:900');
			console.log("POST " + LOCATION_HREF);
			console.log(msg);
			console.groupEnd();
		}

		request.onreadystatechange = function() {
			if (this.readyState == 4) {
				if(this.status == 200) {
					const parser = new DOMParser();
					const doc = parser.parseFromString(this.responseText, 'text/html');

					let error = doc.querySelector("#errorExplanation");

					if(error){
						if (!document.querySelector("#errorExplanation")) {
							let err_div = document.createElement('div');
							err_div.setAttribute("id", "errorExplanation");
							err_div.innerHTML = error.innerHTML;
							document.querySelector('.issue.details').insertAdjacentElement("beforebegin", err_div);

							location.href = "#";
							location.href = "#errorExplanation";
						} else {
							document.querySelector("#errorExplanation").innerHTML = error.innerHTML;
						}

						doc = fetch(LOCATION_HREF, {
							method: 'GET',
							crossDomain: true,
						}).then(res => res.text()).then(data => {
							const parser = new DOMParser();
							return parser.parseFromString(data, 'text/html');
						});
					} else {
						if(document.querySelector("#errorExplanation")) document.querySelector("#errorExplanation").remove();
					}

					document.querySelector('form#issue-form').innerHTML = doc.querySelector('form#issue-form').innerHTML;
					document.querySelector('#all_attributes').innerHTML = doc.querySelector('#all_attributes').innerHTML;
					if(document.querySelector('div.issue.details')){
						document.querySelector('div.issue.details').innerHTML = doc.querySelector('div.issue.details').innerHTML;
					}
					
					if(document.querySelector('#tab-content-history'))
					{
						document.querySelector('#tab-content-history').appendChild(doc.querySelector('#history .journal.has-details:last-child'));
					}
					
					document.querySelector('#issue_lock_version').value = doc.querySelector("#issue_lock_version").value;

					cloneEditForm();

					//set datepicker fallback for input type date
					if (
						document.querySelector('input[type=date]') &&
						$('body').find('input[type=date]').datepickerFallback instanceof Function &&
						typeof datepickerOptions !== 'undefined'
					) {
						$('body').find('input[type=date]').datepickerFallback(datepickerOptions);
					}

					setCSRFTokenInput(doc.querySelector('input[name="authenticity_token"]').value);
					updateCSRFToken(doc.querySelector('input[name="authenticity_token"]').value);

					/* Once we've updated our issue, we have to reset the loadedDate to now to be up to date with the check version */
					loadedDate = new Date();
					
				} else {
					callError(this.status);
				}
			}
		};
		request.send(formData);
	}

	if(check_update_conflict){
		checkVersion(function(distant_version){
			if(distant_version == document.querySelector('#issue_lock_version').value){
				updateIssue(serialized_data);
			} else {

			}
		});
	} else {
		updateIssue(serialized_data);
	}
}


cloneEditForm();
setCSRFTokenInput(document.querySelector('meta[name="csrf-token"]').getAttribute("content"));
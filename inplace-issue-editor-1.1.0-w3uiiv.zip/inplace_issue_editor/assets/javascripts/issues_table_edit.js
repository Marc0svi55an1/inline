var issue_api_key = localStorage.getItem("issue_table_api_key");

var tdId = "";
var custom_id;
$(document).ready(function () {
  var svg_pencil = `<svg width="12" height="14" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
       <path d="M19.6045 5.2808L17.8579 7.02704L13.8584 3.02715L15.6613 1.22427C16.112 0.773551 16.9568 0.773551 17.4642 1.22427L19.7173 3.47742C20.1114 3.98472 20.1114 4.77339 19.6045 5.28069L19.6045 5.2808Z" fill="#1D273C"/>
       <path d="M1.46498 15.4773C3.15509 16.3221 4.56343 17.7304 5.40823 19.3644L0 20.8855L1.46498 15.4773ZM6.25313 18.6319C5.35171 16.9418 3.94336 15.4773 2.25325 14.632L13.0693 3.81592L17.0692 7.81581L6.25313 18.6319Z" fill="#1D273C"/>
       </svg>`;

       //APPEND All ISSUE TD TEXT INSIDE SPAN TAG ::

       var parentContainer = document.querySelector(".controller-issues.action-index");
       if (parentContainer) {
         var trackerCells = parentContainer.querySelectorAll("td.tracker, td.priority, td.start_date, td.category, td.estimated_hours, td.due_date , td.int , td.string , td.date , td.list , td.user , td.float , td.bool , td.text , td.version");
         // Iterate over each <td> element
         trackerCells.forEach(function(cell) {
           // Get the text content of the <td> element
           var trackerText = cell.textContent.trim();
           var spanElement = document.createElement("span");
           spanElement.classList.add("td_text");
           spanElement.textContent = trackerText;
           cell.innerHTML = '';
           cell.appendChild(spanElement);
         });
       }

       //-----------------------------------> 


  $(".controller-issues.action-index .list.issues tr td").each(function (e) {
    if (
      !(
        $(this).hasClass("author") ||
        $(this).hasClass("created_on") ||
        $(this).hasClass("updated_on") ||
        $(this).hasClass("checkbox") ||
        $(this).hasClass("id") ||
        $(this).hasClass("todo") ||
        $(this).hasClass("buttons") ||
        $(this).hasClass("status") ||
        $(this).hasClass("author") ||
        $(this).hasClass("created_on") ||
        $(this).hasClass("closed_on") ||
        $(this).hasClass("parent") ||
        $(this).hasClass("parent-subject") ||
        $(this).hasClass("closed") ||
        $(this).hasClass("spent_hours") ||
        $(this).hasClass("total_spent_hours") ||
        $(this).hasClass("total_estimated_hours") ||
        $(this).hasClass("relations") ||
        $(this).hasClass("last_updated_by") ||
        $(this).hasClass("is_private") ||
        $(this).hasClass("attachments")
      )
    ) {
      $(this).append('<span class="edit-issue">' + svg_pencil + "</span>");
      $(".edit-issue").css("display", "none");
    }
    $(this).hover(
      function () {
        $(this).children(".edit-issue").css('display','inline-block');
      },
      function () {
        $(this).children(".edit-issue").hide();
      }
    );
  });


  //----------------append paercentage-------------

$("tr[id^='issue-'] td.done_ratio").each(function() {
  var $percentP = $(this).find("p.percent");
  var $closedTd = $(this).find(".closed");
  var titleValue = $closedTd.attr("title");
  var percentage = parseInt(titleValue);

  // Check if the title value is valid
  if (isNaN(percentage)) {
    percentage = 0;
  }

  // Create a new p element to display the percentage
  var percentageP = `<label>${percentage}%</label>`;

  // Append the new p element after the existing p.percent element
  $percentP.after(percentageP);
});

//-----------------------------------------------

  // -------------- Toaster Validation ---------------
  toastr.options = {
    closeButton: true,
    debug: false,
    newestOnTop: false,
    progressBar: true,
    positionClass: "toast-top-right",
    preventDuplicates: false,
    onclick: null,
    showDuration: "300",
    hideDuration: "1000",
    timeOut: "2000",
    extendedTimeOut: "1000",
    showEasing: "swing",
    hideEasing: "linear",
    showMethod: "fadeIn",
    hideMethod: "fadeOut",
  };

  function changeFormat(date) {
    var today = new Date(date);
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); //January is 0!
    var yyyy = today.getFullYear();
    return (today = yyyy + "-" + mm + "-" + dd);
  }
  var cs_falid = false;
  var issueId;
  var currentTdClass;
  var projectId;
  var project_val;

  $(".edit-issue").on("click", function (e) {
    $(this).closest("tr").removeClass("hascontextmenu");
    var currentRow = $(this).closest("tr");
    var currentColumn = $(this).closest("td");
    var Id = currentRow.find("td.id").text();
    var issue_id = Id;
    issueId = parseInt(issue_id);

    var clickedtd = $(this).closest("td").attr("class");

    var clickedtd_split = clickedtd.split(" ")[0];

    var cf_Id = clickedtd.substring(3, 5);

    if (tdId != "") {
      $(`#${tdId}`).remove();
      var data = tdId.split("-");
      $(`td#issue_${data[1]}_id-${data[3]}`).css("display", "revert");
    }

    //----------------------------------------------

    // document.onkeydown = function (evt) {
    //   evt = evt || window.event;
    //   var isEscape = false;
    //   if ("key" in evt) {
    //     isEscape = evt.key === "Escape" || evt.key === "Esc";
    //   } else {
    //     isEscape = evt.keyCode === 27;
    //   }
    //   if (isEscape) {
    //     $(`#${tdId}`).each(function (e) {
    //       if (tdId != "") {
    //         $(`#${tdId}`).remove();
    //         var data = tdId.split("-");
    //         $(`td#issue_${data[1]}_id-${data[3]}`).css("display", "revert");
    //         tdId = "";
    //       }
    //     });
    //   }
    // };


    //----------------------------------------------

    // document.onclick = function (evt) {
    //   evt = evt || window.event;
    //   var isEscape = false;
    //   var clickedId = evt.target.id;
    //   if (clickedId ) { // change "my-button-id" to the ID of your button
    //     $(`#${tdId}`).each(function (e) {
    //       if (tdId != "") {
    //         $(`#${tdId}`).remove();
    //         var data = tdId.split("-");
    //         $(`td#issue_${data[1]}_id-${data[3]}`).css("display", "revert");
    //         tdId = "";
    //       }
    //     });
    //   }
    // };

    //-----------------------------------------------
    $(document).on('click', function(e) {
      var $target = $(e.target);
      if(!$target.closest('table').length) {
        // Click occurred outside table, remove tdId
        if (tdId != "") {
          $(`#${tdId}`).remove();
          var data = tdId.split("-");
          $(`td#issue_${data[1]}_id-${data[3]}`).css("display", "revert");
          tdId = "";
        }
      }
    });

    // document.onkeydown = function (evt) {
    //   evt = evt || window.event;
    //   evt = evt || window.event;
    //   if ("buttons" in evt) {
    //       return evt.buttons == 1;
    //   }
    //   var button = evt.which || evt.button;
    //   return button == 1;
    // };



    // $('body').on('click', `#${tdId}`, function(e){
    //   e.preventDefault();
    //   $(`#${tdId}`).each(function (e) {
    //     if (tdId != "") {
    //       $(`#${tdId}`).remove();
    //       var data = tdId.split("-");
    //       $(`td#issue_${data[1]}_id-${data[3]}`).css("display", "revert");
    //       tdId = "";
    //     }
    //   });
    // });

    custom_id = parseInt(cf_Id);
    var rowId = currentRow.attr("id");
    tdId = `dynamic-${clickedtd_split}-edit-${issueId}`;

    $(currentRow)
      .find(currentColumn)
      .attr("id", `issue_${clickedtd_split}_id-${issueId}`);
    currentTdClass = $(this).closest("td").attr("id");

    project_name = currentRow.find("td.project").text();
    projectId = currentRow.find("td.id").text();

    $(".edit-issue").css("display", "none");

    $(`<td id = ${tdId}></td>`).insertAfter("#" + currentTdClass);

    currentRow.find("td#" + currentTdClass).css("display", "none");
    $(this).css("display", "none");

    // ------------- Project ----------------

    if (clickedtd_split == "project") {
      appendProjectDropdown(rowId, currentTdClass, projectId, issueId);
      var currentTdClass;
      // var currentRow;

      $(`#${tdId}`).on("change", function () {
        // var project_val = currentRow.find("td.project a").text();

        var select_project;
        var issue_project_id;
        select_project = $("#project_issue-" + issueId)
          .find("option:selected")
          .html();

        issue_project_id = $("#project_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find("td.project a").html(select_project);

        $(`#${tdId}`).remove();
        $(`tr td#issue_project_id-${issueId}`).css("display", "revert");

        var content1 = {
          project_id: parseInt(issue_project_id),
        };

        jQuery.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),

          success: function (result, status, xhr) {
            // location.reload();
          },

          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    }
    // ------------- Tracker --------------
    else if (clickedtd_split == "tracker") {
      $(`td#issue_project_id-${issueId}`).css("display", "revert");
      $(`#dynamic-project-edit-${issueId}`).remove();

      trackerDropdown(rowId, currentTdClass, projectId, issueId);
      var currentTdClass;
      // var currentRow;
      $(`#${tdId}`).on("change", function () {
        // var tracker_val = currentRow.find("td.tracker").text();
        // $(`td#issue_${clickedtd_split}_id-${issueId}`).html(`<a>${tracker_val}</a>`);

        var select_tracker;
        var select_tracker_id;
        select_tracker = $("#tracker_issue-" + issueId)
          .find("option:selected")
          .html();
        select_tracker_id = $("#tracker_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find("td.tracker span.td_text").html(select_tracker);
        // $("td.tracker").remove();
        // $(select_tracker).append(tracker_val);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_tracker_id-${issueId}`).css("display", "revert");

        var content1 = {
          tracker_id: parseInt(select_tracker_id),
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    }

    //----------- Priorty -------------------------
    else if (clickedtd_split == "priority") {
      $(`td#issue_tracker_id-${issueId}`).css("display", "revert");
      $(`#dynamic-tracker-edit-${issueId}`).remove();
      priorityDropdown(rowId, currentTdClass, issueId);

      $(`#${tdId}`).on("change", function () {
        // var priority_val = currentRow.find("td.priority").text();

        var select_priorty;
        var select_priorty_id;
        select_priorty = $("#priority_issue-" + issueId)
          .find("option:selected")
          .html();
        select_priorty_id = $("#priority_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find("td.priority span.td_text").html(select_priorty);
        // $(select_priorty).append(priority_val);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_priority_id-${issueId}`).css("display", "revert");

        //  ---------- Update values --------------

        var content1 = {
          priority_id: parseInt(select_priorty_id),
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    } else if (clickedtd_split == "assigned_to") {
      appendAssignee(rowId, currentTdClass, issueId);

      var currentTdClass;
      // var currentRow;

      $(`#${tdId}`).on("change", function () {
        // var assigned_to_val = currentRow.find("td.assigned_to a").text();
        // assigned_to_update = currentRow.find("td.assigned_to a").val();

        var assigned_to_update = $("#assignee_to_issue-" + issueId)
          .find("option:selected")
          .val();

        var select_assigned_to;
        select_assigned_to = $(`#assignee_to_issue-${issueId}`)
          .find("option:selected")
          .html();

        currentRow.find("td.assigned_to a").html(select_assigned_to);
        //  $('td.project a').remove();
        // $(select_assigned_to).append(assigned_to_val);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_assigned_to_id-${issueId}`).css("display", "revert");

        //------------------- Update value -------------------------

        var content1 = {
          assigned_to_id: assigned_to_update,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    } else if (clickedtd_split == "subject") {
      // updateSubject(rowId, currentTdClass, issueId);
      var get_subject_text = currentRow.find("td.subject a").text();

      $(`tr#${rowId} td#${tdId}`).append(
        `<input id="dynamic-edit-${currentTdClass}" size="65px" maxlength="255"  title="Issue subject"
        placeholder="Enter subject..." type="text" ></input>`
      );
      let set_subject_text = document.getElementById(
        `dynamic-edit-${currentTdClass}`
      );

      set_subject_text.value = `${get_subject_text}`;

      // $(`.dynamic-edit-${currentTdClass}`);

      $(`#${tdId}`).on("keypress", function (e) {
        if (e.which == 13) {
          var subject_text = $(`#dynamic-edit-${currentTdClass}`).val();

          currentRow.find("td.subject a").html(subject_text);
          // $(subject_text).append(get_subject_text);
          $(`#${tdId}`).remove();
          $(`td#issue_subject_id-${issueId}`).css("display", "revert");

          var content1 = {
            subject: subject_text,
          };

          $.ajax({
            type: "PUT",
            url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
              issue: content1,
            }),
            success: function (result, status, xhr) {
              // location.reload();
            },
            error: function (xhr, status, error) {
              console.log(
                "Result: " +
                  status +
                  " " +
                  error +
                  " " +
                  xhr.status +
                  " " +
                  xhr.statusText
              );
            },
          });
        }
      });
    } else if (clickedtd_split == "start_date") {
      var get_start_date = currentRow
        .find("td.start_date")
        .text()
        .split("\n")[0];

      var changeDateeee = changeFormat(get_start_date);

      $(`tr#${rowId} td#${tdId}`).append(
        `<input id="dynamic-edit-${currentTdClass}" type="date">`
      );

      let set_start_date = document.getElementById(
        `dynamic-edit-${currentTdClass}`
      );

      set_start_date.value = changeDateeee;

      $(`#${tdId}`).on("change", function (e) {
        var updating_date = $(`#dynamic-edit-${currentTdClass}`).val();

        currentRow.find("td.start_date span.td_text").html(updating_date);
        // $(updating_date).append(get_start_date);
        $(`#${tdId}`).remove();
        $(`td#issue_start_date_id-${issueId}`).css("display", "revert");

        var content1 = {
          start_date: updating_date,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            if (xhr.status == 422) {
              let content = JSON.parse(xhr.responseText).errors;

              toastr["error"](content);
            }
          },
        });
      });
    } else if (clickedtd_split == "due_date") {
      var get_due_date = currentRow.find("td.due_date").text();
      var change_dueDate = changeFormat(get_due_date);

      $(`tr#${rowId} td#${tdId}`).append(
        `<input id="dynamic-edit-${currentTdClass}" type="date" >`
      );
      let set_due_date = document.getElementById(
        `dynamic-edit-${currentTdClass}`
      );

      set_due_date.value = `${change_dueDate}`;

      $(`#${tdId}`).on("change", function (e) {
        var updating_due_date = $(`#dynamic-edit-${currentTdClass}`).val();
        currentRow.find("td.due_date span.td_text").html(updating_due_date);
        // $(updating_due_date).append(get_due_date);
        $(`#${tdId}`).remove();
        $(`td#issue_due_date_id-${issueId}`).css("display", "revert");

        var content1 = {
          due_date: updating_due_date,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            if (xhr.status == 422) {
              let content = JSON.parse(xhr.responseText).errors;

              toastr["error"](content);
            }
          },
        });
      });
    }

    // ---------------category ------------------
    else if (clickedtd == "category") {
      categorieDropdown(rowId, currentTdClass, projectId, issueId);
      var currentTdClass;
      // var currentRow;
      $(`#${tdId}`).on("change", function () {
        // var version_val = currentRow.find("td.category").text();

        var select_version;
        var select_version_id;
        select_version = $("#categorie_issue-" + issueId)
          .find("option:selected")
          .html();
        select_version_id = $("#categorie_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find("td.category span.td_text").html(select_version);

        $(`#${tdId}`).remove();
        $(`td#issue_category_id-${issueId}`).css("display", "revert");

        var content1 = {
          category_id: select_version_id,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    } else if (clickedtd_split == "done_ratio") {
      percentDropdown(rowId, currentTdClass);
      $(`#${tdId}`).on("change", function () {
        var ratio_update = $("#percent_issue-" + issueId)
          .find("option:selected")
          .val();
        // var perID = $("#percent_issue-" + issueId + " option:selected").val();

        $(`#${tdId}`).remove();
        $(`td#issue_cf_done_ratio_id-${issueId}`).css("display", "revert");

        var content1 = {
          done_ratio: parseInt(ratio_update),
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    } else if (clickedtd_split == "estimated_hours") {
      // var value = $("." + currentTdClass).text();
      var get_estimated_time = currentRow.find("td.estimated_hours").text();

      $(`tr#${rowId} td#${tdId}`).append(
        `<input size="6" id="dynamic-edit-${currentTdClass}" title="Issue estimated hours"
        placeholder="Enter estimated hours..." type="text" >`
      );
      let set_estimated_time = document.getElementById(
        `dynamic-edit-${currentTdClass}`
      );
      set_estimated_time.value = `${get_estimated_time}`;
      // $(`.dynamic-edit-${currentTdClass}`);

      $(`#${tdId}`).on("keypress", function (e) {
        if (e.which == 13) {
          var estimated_time = $(`#dynamic-edit-${currentTdClass}`).val();
          currentRow.find("td.estimated_hours span.td_text").html(estimated_time);
          // $(estimated_time).append(get_estimated_time);
          $(`#${tdId}`).remove();
          $(`td#issue_estimated_hours_id-${issueId}`).css("display", "revert");

          var content1 = {
            estimated_hours: parseInt(estimated_time),
          };

          $.ajax({
            type: "PUT",
            url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({
              issue: content1,
            }),
            success: function (result, status, xhr) {
              // location.reload();
            },
            error: function (xhr, status, error) {
              console.log(
                "Result: " +
                  status +
                  " " +
                  error +
                  " " +
                  xhr.status +
                  " " +
                  xhr.statusText
              );
            },
          });
        }
      });
    }

    //-------------Custom String Type-------------------
    else if (clickedtd === `cf_${custom_id} string`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

              $(`tr#${rowId} td#${tdId}`).append(
                `<input size="65px" id="dynamic-edit-${currentTdClass}" maxlength="255" title="Issue custom field"
                placeholder="Enter custom field text..." type="text" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${get_cf_id_text}`;
              $(`.dynamic-edit-${currentTdClass}`);

              $(`#${tdId}`).on("keypress", function (e) {
                if (e.which == 13) {
                  var custom_field_array = [];
                  var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                  currentRow.find(`td.cf_${custom_id} span.td_text`).html(cf_value);
                  // $(cf_value).append(get_cf_id_text);
                  $(`#${tdId}`).remove();
                  $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                    "display",
                    "revert"
                  );

                  custom_field_array.push({
                    id: custom_id,
                    value: `${cf_value}`,
                  });

                  var content1 = {
                    custom_fields: custom_field_array,
                  };

                  $.ajax({
                    type: "PUT",
                    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content1,
                    }),
                    success: function (result, status, xhr) {
                      // location.reload();
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;

                        toastr["error"](content);
                      }
                    },
                  });
                }
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }
    //-------------Custom Long long-------------------
    else if (clickedtd === `cf_${custom_id} text`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

              $(`tr#${rowId} td#${tdId}`).append(
                `<input size="15" id="dynamic-edit-${currentTdClass}" maxlength="255" title="Issue custom field"
                placeholder="Enter custom field text..." type="text" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${get_cf_id_text}`;
              $(`.dynamic-edit-${currentTdClass}`);

              $(`#${tdId}`).on("keypress", function (e) {
                if (e.which == 13) {
                  var custom_field_array = [];
                  var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                  currentRow.find(`td.cf_${custom_id} span.td_text`).html(cf_value);
                  // $(cf_value).append(get_cf_id_text);
                  $(`#${tdId}`).remove();
                  $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                    "display",
                    "revert"
                  );

                  custom_field_array.push({
                    id: custom_id,
                    value: `${cf_value}`,
                  });

                  var content1 = {
                    custom_fields: custom_field_array,
                  };

                  $.ajax({
                    type: "PUT",
                    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content1,
                    }),
                    success: function (result, status, xhr) {
                      // location.reload();
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;

                        toastr["error"](content);
                      }
                    },
                  });
                }
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }

    //-------------Custom Integer Type-------------------
    else if (clickedtd === `cf_${custom_id} int`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

              $(`tr#${rowId} td#${tdId}`).append(
                `<input size="6" id="dynamic-edit-${currentTdClass}" title="Issue custom field"
                placeholder="Enter only integer number..." type="number" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${get_cf_id_text}`;
              $(`.dynamic-edit-${currentTdClass}`);

              $(`#${tdId}`).on("keypress", function (e) {
                if (e.which == 13) {
                  var custom_field_array = [];
                  var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                  currentRow.find(`td.cf_${custom_id} span.td_text`).html(cf_value);
                  $(cf_value).append(get_cf_id_text);
                  $(`#${tdId}`).remove();
                  $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                    "display",
                    "revert"
                  );

                  custom_field_array.push({
                    id: custom_id,
                    value: cf_value,
                  });

                  var content1 = {
                    custom_fields: custom_field_array,
                  };

                  $.ajax({
                    type: "PUT",
                    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content1,
                    }),
                    success: function (result, status, xhr) {
                      // location.reload();
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;

                        toastr["error"](content);
                      }
                    },
                  });
                }
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }
    //-------------Custom Date Type-------------------
    else if (clickedtd === `cf_${custom_id} date`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();
              var cf_date = changeFormat(get_cf_id_text);

              $(`tr#${rowId} td#${tdId}`).append(
                `<input id="dynamic-edit-${currentTdClass}" type="date" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${cf_date}`;

              $(`#${tdId}`).on("change", function (e) {
                // if (e.which == 13) {
                var custom_field_array = [];
                var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                currentRow.find(`td.cf_${custom_id} span.td_text`).html(cf_value);
                $(cf_value).append(get_cf_id_text);
                $(`#${tdId}`).remove();
                $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                  "display",
                  "revert"
                );

                custom_field_array.push({
                  id: custom_id,
                  value: `${cf_value}`,
                });

                var content1 = {
                  custom_fields: custom_field_array,
                };

                $.ajax({
                  type: "PUT",
                  url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content1,
                  }),
                  success: function (result, status, xhr) {
                    // location.reload();
                  },
                  error: function (xhr, status, error) {
                    console.log(
                      "Result: " +
                        status +
                        " " +
                        error +
                        " " +
                        xhr.status +
                        " " +
                        xhr.statusText
                    );
                  },
                });
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }
    //-------------Custom List Type-------------------
    else if (clickedtd === `cf_${custom_id} list`) {
      getCustomData(rowId, currentTdClass, issueId);

      $(`#${tdId}`).on("change", function () {
        var custom_field_array = [];
        // var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

        var select_cf_list;
        var select_cf_list_id;
        select_cf_list = $("#cf_list_issue-" + issueId)
          .find("option:selected")
          .html();
        select_cf_list_id = $("#cf_list_issue-" + issueId)
          .find("option:selected")
          .text();
        // cf_select_list_split = select_cf_list_id.split(" ")[0];

        currentRow.find(`td.cf_${custom_id} span.td_text`).html(select_cf_list);
        // $(select_cf_list).append(get_cf_id_text);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_cf_${custom_id}_id-${issueId}`).css("display", "revert");

        //  ----------------- update values -------------------------

        custom_field_array.push({
          id: custom_id,
          value: `${select_cf_list_id}`,
        });

        var content1 = {
          custom_fields: custom_field_array,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    }
    //-------------Custom User Type-------------------
    else if (clickedtd == `cf_${custom_id} user`) {
      // var currentRow;
      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              appendAssignee(rowId, currentTdClass, issueId);
              var currentTdClass;
             
              var assigned_to_update;

              $(`#${tdId}`).on("change", function () {
                var custom_field_array = [];
                // var get_cf_id_text = currentRow.find(`td.cf_${custom_id} a`).text();

                var select_cf_user;
                var select_cf_user_id;
                select_cf_user = $("#assignee_to_issue-" + issueId)
                  .find("option:selected")
                  .html();
                select_cf_user_id = $("#assignee_to_issue-" + issueId)
                  .find("option:selected")
                  .val();

                currentRow.find(`td.cf_${custom_id} span.td_text`).html(select_cf_user);
                // $(select_cf_user).append(get_cf_id_text);

                // $("select").css("display", "none");
                $(`#${tdId}`).remove();
                $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                  "display",
                  "revert"
                );

                //  ----------------- update values -------------------------

                custom_field_array.push({
                  id: custom_id,
                  value: `${select_cf_user_id}`,
                });

                var content1 = {
                  custom_fields: custom_field_array,
                };

                $.ajax({
                  type: "PUT",
                  url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content1,
                  }),
                  success: function (result, status, xhr) {
                    // location.reload();
                  },
                  error: function (xhr, status, error) {
                    console.log(
                      "Result: " +
                        status +
                        " " +
                        error +
                        " " +
                        xhr.status +
                        " " +
                        xhr.statusText
                    );
                  },
                });
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    } //-------------Custom Float Type-------------------
    else if (clickedtd === `cf_${custom_id} float`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr, textStatus, jqXHR) {
          var issueee = data.issue.custom_fields;
          // console.log(issueee,"issue_cf_id");
          for (var i = 0; i < issueee.length; i++) {
            var customFieldId = issueee[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

              $(`tr#${rowId} td#${tdId}`).append(
                `<input size="6" id="dynamic-edit-${currentTdClass}" title="Issue custom field"
                    placeholder="Enter only decimal number..." type="number" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${get_cf_id_text}`;
              $(`.dynamic-edit-${currentTdClass}`);

              $(`#${tdId}`).on("keypress", function (e) {
                if (e.which == 13) {
                  var custom_field_array = [];
                  var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                  currentRow.find(`td.cf_${custom_id} span.td_text`).html(cf_value);
                  // $(cf_value).append(get_cf_id_text);
                  $(`#${tdId}`).remove();
                  $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                    "display",
                    "revert"
                  );

                  custom_field_array.push({
                    id: custom_id,
                    value: cf_value,
                  });

                  var content1 = {
                    custom_fields: custom_field_array,
                  };

                  $.ajax({
                    type: "PUT",
                    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content1,
                    }),
                    success: function (data, status, xhr) {
                      console.log(xhr.status);
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;
                        console.log(content);
                        toastr["error"](content);
                      }
                    },
                  });
                }
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue."
            );
          }
        },
        error: function (xhr, jqXHR, status, error) {
          console.log(jqXHR, "status");
        },
      });
    }
    //-------------Custom Link Type-------------------
    else if (clickedtd === `cf_${custom_id} link`) {
      // var value = $("." + currentTdClass).text();

      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              var get_cf_id_text = currentRow
                .find(`td.cf_${custom_id} a`)
                .text();

              $(`tr#${rowId} td#${tdId}`).append(
                `<input size="15" id="dynamic-edit-${currentTdClass}" title="Issue custom field"
                placeholder="Enter http address..." type="text" >`
              );
              let set_cf_id_text = document.getElementById(
                `dynamic-edit-${currentTdClass}`
              );
              set_cf_id_text.value = `${get_cf_id_text}`;
              $(`.dynamic-edit-${currentTdClass}`);

              $(`#${tdId}`).on("keypress", function (e) {
                if (e.which == 13) {
                  var custom_field_array = [];
                  var cf_value = $(`#dynamic-edit-${currentTdClass}`).val();
                  currentRow.find(`td.cf_${custom_id} a`).html(cf_value);
                  // $(cf_value).append(get_cf_id_text);
                  $(`#${tdId}`).remove();
                  $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                    "display",
                    "revert"
                  );

                  custom_field_array.push({
                    id: custom_id,
                    value: `${cf_value}`,
                  });

                  var content1 = {
                    custom_fields: custom_field_array,
                  };

                  $.ajax({
                    type: "PUT",
                    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                      issue: content1,
                    }),
                    success: function (result, status, xhr) {
                      // location.reload();
                    },
                    error: function (xhr, status, error) {
                      if (xhr.status == 422) {
                        let content = JSON.parse(xhr.responseText).errors;

                        toastr["error"](content);
                      }
                    },
                  });
                }
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue."
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }

    //-------------Custom List Type-------------------
    else if (clickedtd === `cf_${custom_id} bool`) {
      getCustomData(rowId, currentTdClass, issueId);

      $(`#${tdId}`).on("change", function () {
        var custom_field_array = [];
        // var get_cf_id_text = currentRow.find(`td.cf_${custom_id}`).text();

        var select_cf_list;
        var select_cf_list_id;
        select_cf_list = $("#cf_bool_issue-" + issueId)
          .find("option:selected")
          .html();
        select_cf_list_id = $("#cf_bool_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find(`td.cf_${custom_id} span.td_text`).html(select_cf_list);
        // $(select_cf_list).append(get_cf_id_text);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_cf_${custom_id}_id-${issueId}`).css("display", "revert");

        //  ----------------- update values -------------------------

        custom_field_array.push({
          id: custom_id,
          value: `${select_cf_list_id}`,
        });

        var content1 = {
          custom_fields: custom_field_array,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    }
    //------------------- issue versions --------------------
    else if (clickedtd_split == "fixed_version") {
      // $(`#dynamic-project-edit-${issueId}`).remove();
      // $(`#issue_project_id-${issueId}`).css('display','block');
      versionDropdown(rowId, currentTdClass, projectId, issueId);
      var currentTdClass;
      // var currentRow;
      $(`#${tdId}`).on("change", function () {
        // var version_val = currentRow.find("td.fixed_version").text();

        var select_version;
        var select_version_id;
        select_version = $("#version_issue-" + issueId)
          .find("option:selected")
          .html();
        select_version_id = $("#version_issue-" + issueId)
          .find("option:selected")
          .val();

        currentRow.find("td.fixed_version span.td_text").html(select_version);
        // $("td.tracker").remove();
        // $(select_version).append(version_val);

        // $("select").css("display", "none");
        $(`#${tdId}`).remove();
        $(`td#issue_fixed_version_id-${issueId}`).css("display", "revert");

        var content1 = {
          fixed_version_id: select_version_id,
        };

        $.ajax({
          type: "PUT",
          url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
          dataType: "json",
          contentType: "application/json",
          data: JSON.stringify({
            issue: content1,
          }),
          success: function (result, status, xhr) {
            // location.reload();
          },
          error: function (xhr, status, error) {
            console.log(
              "Result: " +
                status +
                " " +
                error +
                " " +
                xhr.status +
                " " +
                xhr.statusText
            );
          },
        });
      });
    }
    //------------------- issue custom versions --------------------
    else if (clickedtd == `cf_${custom_id} version`) {
      console.log(`cf_${custom_id}`, 'CFFF');
      $.ajax({
        type: "GET",
        url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
        dataType: "json",
        contentType: "application/json",
        success: function (data, status, xhr) {
          var c_f_issues_ids = data.issue.custom_fields;
          for (var i = 0; i < c_f_issues_ids.length; i++) {
            var customFieldId = c_f_issues_ids[i].id;
            if (customFieldId == custom_id) {
              cs_falid = false;
              versionDropdown(rowId, currentTdClass, projectId, issueId);
              var currentTdClass;
              // var currentRow;
              $(`#${tdId}`).on("change", function () {
                var custom_field_array = [];

                var select_cf_version;
                var select_cf_version_id;
                select_cf_version = $("#version_issue-" + issueId)
                  .find("option:selected")
                  .html();

                  console.log(select_cf_version,'selected_version');
                select_cf_version_id = $("#version_issue-" + issueId)
                  .find("option:selected")
                  .val();

                currentRow.find(`td.cf_${custom_id} span.td_text`).html(select_cf_version);
                // $("td.tracker").remove();
                // $(select_cf_version).append(cf_version_val);

                // $("select").css("display", "none");
                $(`#${tdId}`).remove();
                $(`td#issue_cf_${custom_id}_id-${issueId}`).css(
                  "display",
                  "revert"
                );

                custom_field_array.push({
                  id: custom_id,
                  value: select_cf_version_id,
                });

                var content1 = {
                  custom_fields: custom_field_array,
                };

                $.ajax({
                  type: "PUT",
                  url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({
                    issue: content1,
                  }),
                  success: function (result, status, xhr) {
                    // location.reload();
                  },
                  error: function (xhr, status, error) {
                    console.log(
                      "Result: " +
                        status +
                        " " +
                        error +
                        " " +
                        xhr.status +
                        " " +
                        xhr.statusText
                    );
                  },
                });
              });
              break;
            } else {
              cs_falid = true;
            }
          }
          if (cs_falid == true) {
            toastr["error"](
              "This custom field is not belong to this issue"
            );
          }
        },
        error: function (xhr, status, error) {},
      });
    }
  });
});

var url = window.location.origin;

function appendProjectDropdown(
  rowId,
  currentTdClass,
  projectId,
  selectedProject
) {
  $.ajax({
    url: `${url}/projects.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    data: { limit: 100 },
    success: function (data) {
      var rowtext = $(`tr#${rowId}`).find("td.project a").text();
      var issue_project = rowtext.split("\n")[0];
      projects = data.projects;
      var projectDropdown = "<select id= project_" + rowId + ">";
      for (let i = 0; i < projects.length; i++) {
        projectDropdown +=
          `<option ${
            issue_project == projects[i].name ? "selected" : ""
          } value = ${projects[i].id}>` +
          projects[i].name +
          "</option>";
      }

      $(`tr#${rowId} td#${tdId}`).append(projectDropdown);
      // $(`#project_${rowId}`).prepend('<option value="  "></option>');
    },
    error: function () {},
  });
}

function priorityDropdown(rowId, currentTdClass, selectedPriority) {
  $.ajax({
    url: `${url}/enumerations/issue_priorities.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    success: function (data) {
      var rowtext = $(`tr#${rowId}`).find("td.priority").text();
      var issue_priority = rowtext.split("\n")[0];

      priorities = data.issue_priorities;

      var priorityDropdown = "<select id= priority_" + rowId + ">";
      for (let i = 0; i < priorities.length; i++) {
        priorityDropdown +=
          `<option ${
            issue_priority == priorities[i].name ? "selected" : ""
          } value = ${priorities[i].id}>` +
          priorities[i].name +
          "</option>";
      }
      $(`tr#${rowId} td#${tdId}`).append(priorityDropdown);
    },
    error: function () {},
  });
}

function appendAssignee(rowId, currentTdClass, issueId) {
  var project_id;
  $.ajax({
    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    data: { limit: 100 },
    success: function (data) {
      var issues_data = data.issue;
      project_id = issues_data.project.id;

      $.ajax({
        url: `${url}/projects/${project_id}/memberships.json?key=${issue_api_key}`,
        type: "GET",
        crossDomain: true,
        dataType: "json",
        success: function (data) {
          var rowtext = $(`tr#${rowId}`).find("td.assigned_to a").text();
          var issue_assignee = rowtext.split("\n")[0];
          var members = data.memberships;

          var memberDropdown = "<select id= assignee_to_" + rowId + ">";

          for (var i = 0; i < members.length; i++) {
            if (members[i].hasOwnProperty("user")) {
              var member_id = members[i].user.id;
              var member_name = members[i].user.name;

              memberDropdown +=
                `<option ${
                  issue_assignee == members[i].user.name ? "selected" : ""
                } value = ${member_id}>` +
                member_name +
                "</option>";
            }
          }

          $(`tr#${rowId} td#${tdId}`).append(memberDropdown);
          $(`#assignee_to_${rowId}`).prepend(`<option value="" ></option>`);
          if ($(`select#assignee_to_${rowId} option`).length == 1) {
            toastr["error"]("This project does not have a assignee");
            $(`#assignee_to_${rowId}`).css("display", "none");
          }
        },
        error: function () {},
      });
    },
    error: function () {},
  });
}

// ---------------------- Tracker api ----------------

function trackerDropdown(rowId, currentTdClass, projectId, issueId) {
  var tracker_id;

  $.ajax({
    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    success: function (data) {
      var issues_data = data.issue;
      tracker_id = issues_data.project.id;
      var api_key = "b114b9aeb870cc49e901aaf223ea422fcbd669f8";
      var id = projectId;

      $.ajax({
        url: `${url}/projects/${tracker_id}.json?key=${issue_api_key}&&include=trackers`,
        type: "GET",
        crossDomain: true,
        dataType: "json",
        success: function (data) {
          var project = data;

          var trackers = data.project.trackers;
          var rowtext = $(`tr#${rowId}`).find("td.tracker").text();
          var issue_tracker = rowtext.split("\n")[0];

          var trackerDropdown = "<select id= tracker_" + rowId + ">";
          for (let i = 0; i < trackers.length; i++) {
            trackerDropdown +=
              `<option ${
                issue_tracker == trackers[i].name ? "selected" : ""
              } value = ${trackers[i].id}>` +
              trackers[i].name +
              "</option>";
          }

          $(`tr#${rowId} td#${tdId}`).append(trackerDropdown);
        },
        error: function () {},
      });
    },
    error: function () {},
  });
}

// ----------------- version api --------------

function versionDropdown(rowId, currentTdClass, projectId, issueId) {
  var version_id;
  $.ajax({
    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    data: { limit: 100 },
    success: function (data) {
      var issues_data = data.issue;
      version_id = issues_data.project.id;

      var id = projectId;

      $.ajax({
        url: `${url}/projects/${version_id}/versions.json?key=${issue_api_key}`,
        type: "GET",
        crossDomain: true,
        dataType: "json",
        success: function (data) {
          var rowtext = $(`tr#${rowId}`).find("td.fixed_version a").text();
          var issue_version = rowtext.split("\n")[0];

          versions = data.versions;
          var versionDropdown = "<select id= version_" + rowId + ">";
          for (let i = 0; i < versions.length; i++) {
            versionDropdown +=
              `<option ${
                issue_version == versions[i].name ? "selected" : ""
              } value = ${versions[i].id}>` +
              versions[i].name +
              "</option>";
          }
          $(`tr#${rowId} td#${tdId}`).append(versionDropdown);
          $(`#version_${rowId}`).prepend(`<option value="" ></option>`);
          if ($(`select#version_${rowId} option`).length == 1) {
            toastr["error"]("This project does not have a fixed version.");
            $(`#version_${rowId}`).css("display", "none");
          }
        },
        error: function () {},
      });
    },
    error: function () {},
  });
}

// ----------------- categories --------------

function categorieDropdown(rowId, currentTdClass, projectId, issueId) {
  var categorie_id;
  $.ajax({
    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    success: function (data) {
      var issues_data = data.issue;
      categorie_id = issues_data.project.id;

      var id = projectId;

      $.ajax({
        url: `${url}/projects/${categorie_id}/issue_categories.json?key=${issue_api_key}`,
        type: "GET",
        crossDomain: true,
        dataType: "json",
        success: function (data) {
          var rowtext = $(`tr#${rowId}`).find("td.category").text();
          var issue_categories = rowtext.split("\n")[0];

          var categories = data.issue_categories;

          var categorieDropdown = "<select id= categorie_" + rowId + ">";
          for (let i = 0; i < categories.length; i++) {
            categorieDropdown +=
              `<option ${
                issue_categories == categories[i].name ? "selected" : ""
              } value = ${categories[i].id}>` +
              categories[i].name +
              "</option>";
          }
          $(`tr#${rowId} td#${tdId}`).append(categorieDropdown);
          if ($(`select#categorie_${rowId} option`).length == 0) {
            toastr["error"]("This project does not have a category.");
            $(`#categorie_${rowId}`).css("display", "none");
          }
        },
        error: function () {},
      });
    },
    error: function () {},
  });
}

function percentDropdown(rowId, currentTdClass) {
  var percent_data = [
    "0",
    "10",
    "20",
    "30",
    "40",
    "50",
    "60",
    "70",
    "80",
    "90",
    "100",
  ];

  var percentDropdown = $("<select>", { id: "percent_" + rowId });

  for (let i = 0; i < percent_data.length; i++) {
    var option = $("<option>", {
      value: percent_data[i],
      text: percent_data[i] + "%",
    });

    percentDropdown.append(option);
  }
  $(`tr#${rowId} td#${tdId}`).append(percentDropdown);
}
function getCustomData(rowId, currentTdClass, issueId) {
  var cf_valid = false;
  $.ajax({
    url: `${url}/issues/${issueId}.json?key=${issue_api_key}`,
    type: "GET",
    crossDomain: true,
    dataType: "json",
    success: function (data) {
      var issues_data = data.issue;
      var c_f_issue = issues_data.custom_fields;

      var project_tracker = issues_data.tracker.id;

      $.ajax({
        type: "GET",
        url: url + "/custom_fields.json?key=" + issue_api_key + " ",
        dataType: "json",
        async: false,
        success: function (result, index, xhr) {
          var rowtext = $(`tr#${rowId}`).find(`td.cf_${custom_id}`).text();
          var issue_cf = rowtext.split("\n")[0];
          var custom_cf_Dropdown;
          var custom_cf_Dropdown_bool;
          result.custom_fields.forEach((data, index) => {
            if (data.customized_type === "issue") {
              if (data.id == custom_id) {
                if (data.field_format == "list") {
                  var cf_list = data.possible_values;
                  for (let i = 0; i < c_f_issue.length; i++) {
                    var cf_issue_ids = c_f_issue[i].id;
                    //  console.log(cf_issue_ids, "issue cf ids");
                    if (cf_issue_ids == custom_id) {
                      cf_valid = false;
                      custom_cf_Dropdown = "<select id= cf_list_" + rowId + ">";
                      for (let i = 0; i < cf_list.length; i++) {
                        custom_cf_Dropdown +=
                          `<option ${
                            issue_cf == cf_list[i].label ? "selected" : ""
                          } value = ${cf_list[i].value}>` +
                          cf_list[i].label +
                          "</option>";
                      }
                      break;
                    } else {
                      //  toastr["error"]('custom field tracker is not belongs to project tracker');
                      cf_valid = true;
                    }
                  }
                  if (cf_valid == true) {
                    toastr["error"](
                      "This custom field is not belong to this issue"
                    );
                  }
                } else if (data.field_format == "bool") {
                  var cf_bool = data.possible_values;
                  for (let i = 0; i < c_f_issue.length; i++) {
                    var cf_issue_bool_ids = c_f_issue[i].id;

                    if (cf_issue_bool_ids == custom_id) {
                      cf_valid = false;
                      custom_cf_Dropdown = "<select id= cf_bool_" + rowId + ">";
                      for (let i = 0; i < cf_bool.length; i++) {
                        custom_cf_Dropdown +=
                          `<option ${
                            issue_cf == cf_bool[i].label ? "selected" : ""
                          } value = ${cf_bool[i].value}>` +
                          cf_bool[i].label +
                          "</option>";
                      }
                      break;
                    } else {
                      cf_valid = true;
                    }
                  }
                  if (cf_valid == true) {
                    toastr["error"](
                      "This custom field is not belong to this issue"
                    );
                  }
                }
              }
            }
          });
          $(`tr#${rowId} td#${tdId}`).append(custom_cf_Dropdown);
        },
      });
    },
    error: function () {},
  });
}
